package com.example.member.article.comment;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class ApiCommentController {

    private final CommentService commentService;

    //댓글 수정
    @PostMapping("/article/commentEdit/{id}")
    public ResponseEntity<CommentDto> update(@PathVariable Long comment_id,
                                             @RequestBody CommentDto dto){
        //서비스에 위임
        CommentDto updateDto = commentService.update(comment_id, dto);

        return ResponseEntity.status(HttpStatus.OK).body(updateDto);

    }

}
