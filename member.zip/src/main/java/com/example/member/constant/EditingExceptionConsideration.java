package com.example.member.constant;

public enum EditingExceptionConsideration {
    Y, N
}
