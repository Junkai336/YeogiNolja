package com.example.member.constant;

public enum CategoryStatus {

    NOTICE, FREE

}
