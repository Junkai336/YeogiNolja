package com.example.member.constant;

public enum ReservationStatus {

    RESERVED, AVAILABLE
    // 예약중, 사용 가능

}