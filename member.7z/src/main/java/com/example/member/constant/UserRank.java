package com.example.member.constant;

public enum UserRank {
    BRONZE, SILVER, GOLD, PLATINUM, DIAMOND, VIP
}
