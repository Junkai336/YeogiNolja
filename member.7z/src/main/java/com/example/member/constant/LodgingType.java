package com.example.member.constant;

public enum LodgingType {

    PENSION, POOLVILLA

}
