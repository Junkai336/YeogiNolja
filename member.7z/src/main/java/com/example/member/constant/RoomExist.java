package com.example.member.constant;

public enum RoomExist {

    Y, N

}
